Sample React JS Project For Internship


To install packages for the first time:
yarn install

To start the service:
yarn start

Open the following URL in the browser:
http://localhost:3000/
