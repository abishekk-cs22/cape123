import { configureStore, combineReducers  } from '@reduxjs/toolkit';
import storage from 'redux-persist/lib/storage';
import { persistReducer, persistStore } from 'redux-persist';
import { encryptTransform } from 'redux-persist-transform-encrypt';

import { studentsReducer } from './students.slice';

export * from './students.slice';

const secretKeyForLocalStorage = 'my-super-secret-key-is-always-secret-for-cs';

const rootPersistConfig = {
    key: 'root',
//    storage: storageSession,
    storage: storage,
    whitelist: [],
    blacklist: [],
    transforms: [encryptTransform({
        secretKey: secretKeyForLocalStorage,
        onError: function(error) {
            // handle the error
        }
    })]
};

const authPersistConfig = {
    key: 'auth',
//    storage: storageSession,
    storage: storage,
    transforms: [encryptTransform({
        secretKey: secretKeyForLocalStorage,
        onError: function(error) {
            // handle the error
        }
    })]
};

//const persistedAuthReducer = persistReducer(authPersistConfig, authReducer);

const rootReducer = combineReducers(
    {
        students:  studentsReducer,
    }
);

const persistedReducer = persistReducer(rootPersistConfig, rootReducer);

export const store = configureStore({
    reducer: persistedReducer,
    devTools: false,
    middleware: getDefaultMiddleware => getDefaultMiddleware({
        serializableCheck: false
    })
});

export const persistor = persistStore(store);