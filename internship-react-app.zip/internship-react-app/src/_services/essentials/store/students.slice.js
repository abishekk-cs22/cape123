import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import axios from 'axios';

// create slice

const initialState = createInitialState();
const extraActions = createExtraActions();
const extraReducers = createExtraReducers();
const slice = createSlice({name: 'students' , initialState, extraReducers });

// exports

export const studentsActions = { ...slice.actions, ...extraActions };
export const studentsReducer = slice.reducer;

// implementation

function createInitialState() {
    return {
        list: null,
        item: null,
    }
}

function createExtraActions() {

    return {
        getAll: getAll(),
        getById: getById(),
        getNewEntity: getNewEntity(),
        create: create(),
        update: update(),
        delete: _delete(),
    };

    function getAll() {
        return createAsyncThunk(
            `students/getAll`,
            async function () {
                try {
                    const response = await axios.get(`http://localhost:5000/api/students`);
                    return response.data;
                } catch (error) {
                    return [];
                }
            }
        );
    }

    function getById() {
        return createAsyncThunk(
            `students/getById`,
            async function (id) {
                try {
                    const response = await axios.get(`http://localhost:5000/api/students/${id}`);
                    //const token = response.token;
                    const responseData = response.data;
                    //console.log('responseData: '+ JSON.stringify(responseData));
                    // set auth user in redux state
                    return responseData;
                } catch (error) {
                    return {}
                }
            }

        );
    }

    function getNewEntity() {
        return createAsyncThunk(
            `students/getNewEntity`,
            async function (entity) {
                //alert('entity: '+JSON.stringify(entity));
                return entity;
            }
        );
    }


    function create() {
        return createAsyncThunk(
            `students/create`,
            async function ({ data }) {
                try {
                    const response = await axios.post(`http://localhost:5000/api/student`, data);
                    const responseData = response.data;
                    return responseData;
                } catch (error) {
                    return {}
                }
            }
        );
    }

    function update() {
        return createAsyncThunk(
            `students/update`,
            async function ({ id, data }) {
                try {
                    const response = await axios.put(`http://localhost:5000/api/student/${id}`, data);
                    const responseData = response.data;
                    return responseData;
                } catch (error) {
                    return {}
                }
            }
        );
    }

    // prefixed with underscore because delete is a reserved word in javascript
    function _delete() {
        return createAsyncThunk(
            `students/_delete`,
            async function (id) {
                try {
                    const response = await axios.delete(`http://localhost:5000/api/student/${id}`);
                    const responseData = response.data;
                    return responseData;
                } catch (error) {
                    return {}
                }
            }
        );
    }

}

function createExtraReducers() {
    return (builder) => {
        getAll();
        getById();
        update();
        _delete();

        function getAll() {
            var { pending, fulfilled, rejected } = extraActions.getAll;
            builder
                .addCase(pending, (state) => {
                    state.list = { loading: true };
                })
                .addCase(fulfilled, (state, action) => {
                    state.list = { value: action.payload };
                })
                .addCase(rejected, (state, action) => {
                    state.list = { error: action.error };
                });
        }

        function getById() {
            var { pending, fulfilled, rejected } = extraActions.getById;
            builder
                .addCase(pending, (state) => {
                    state.item = { loading: true };
                })
                .addCase(fulfilled, (state, action) => {
                    state.item = { value: action.payload };
                })
                .addCase(rejected, (state, action) => {
                    state.item = { error: action.error };
                });
        }

        function update() {
            var { pending, fulfilled, rejected } = extraActions.update;
            builder
                .addCase(pending, (state) => {
                    state.item = { loading: true };
                })
                .addCase(fulfilled, (state, action) => {
                    state.item = { value: action.payload };
                })
                .addCase(rejected, (state, action) => {
                    state.item = { error: action.error };
                });
        }

        function _delete() {
            var { pending, fulfilled, rejected } = extraActions.delete;
            builder
                .addCase(pending, (state, action) => {
                    //const user = state.list.value.find(x => x.id === action.meta.arg);
                    //user.isDeleting = true;
                })
                .addCase(fulfilled, (state, action) => {
                    //state.list.value = state.list.value.filter(x => x.id !== action.meta.arg);
                })
                .addCase(rejected, (state, action) => {
                    //const user = state.list.value.find(x => x.id === action.meta.arg);
                    //user.isDeleting = false;
                });
        }

    };
}
