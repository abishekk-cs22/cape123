import React from "react";
import { Bio } from './_pages/application/Bio'
import { Evans } from './_pages/application/Evans'
import { Home } from './_pages/application/Home'
import Container from '@mui/material/Container';
import { useNavigate, useLocation } from 'react-router-dom';
import { history } from '_services/essentials/helpers';
import { Routes, Route } from 'react-router-dom';
import {Layout as StudentLayout} from './_pages/application/students'

export { App };

function App() {

    history.navigate = useNavigate();
    history.location = useLocation();

    return (
        <Container fixed>
            <Routes>
                <Route exact path="/" element={<Home/>}/>
                <Route exact path="/bio" element={<Bio/>}/>
                <Route exact path="/evans" element={<Evans/>}/>
                <Route path="students/*" element={<StudentLayout />} />
            </Routes>
        </Container>
    );
}