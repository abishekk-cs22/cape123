import React, { useEffect, useState, useRef } from 'react';
import { useParams } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as Yup from 'yup';
import { useSelector, useDispatch } from 'react-redux';
import SaveOutlinedIcon from '@mui/icons-material/SaveOutlined';
import KeyboardDoubleArrowDownIcon from '@mui/icons-material/KeyboardDoubleArrowDown';
import KeyboardDoubleArrowUpIcon from '@mui/icons-material/KeyboardDoubleArrowUp';
import CancelPresentationIcon from '@mui/icons-material/CancelPresentation';
import NotificationsIcon from '@mui/icons-material/Notifications';
import PersonAddIcon from '@mui/icons-material/PersonAdd';

import {history, uxscreen} from '../../../_services/essentials/helpers';

import { TextField, Button, Stack, Select, MenuItem, InputLabel, FormControl} from '@mui/material';
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";

import {studentsActions} from "../../../_services/essentials/store";

export { AddEdit };

function AddEdit(props) {

    const pageParams = useParams();

    const { id } = pageParams;

    const dispatch = useDispatch();

    const entity = useSelector(x => x.students?.item);

    // form validation rules
    const validationSchema = Yup.object().shape({
        name: Yup.string().required('Student Name is required'),
        address: Yup.string().required('Address is required'),
        phone: Yup.string().required('Phone number is required'),
        email: Yup.string().email("Please enter a valid Email")
            .required('Required*'),
    });
    const formOptions = { resolver: yupResolver(validationSchema) };
    // get functions to build form with useForm() hook
    const { register, handleSubmit, reset, formState, setValue } = useForm(formOptions);
    const { errors } = formState;

    const newEntity = {
        "name": "",
        "address": "",
        "phone": "",
        "email": "",
        "gender": {
            "id": 1
        }
    };

    useEffect(() => {
        if(id) {
            dispatch(studentsActions.getById(id)).unwrap()
                .then(entity => {
                    reset(entity);
                });
        } else {
            dispatch(studentsActions.getNewEntity(newEntity)).unwrap()
                .then(entity => {
                    reset(entity);
                });
        }
    }, [id]);

    async function deleteStudentDetails(id){
        await dispatch(studentsActions.delete(id));
        const message = `Student details has been deleted successfully`;
        alert(message);
        history.navigate('/students');
    }

    async function onSubmit(data) {
        try {
            // create or update user based on id param
            let message;

            if (id) {
                await dispatch(studentsActions.update({id, data})).unwrap();
                message = `Student details has been Updated successfully`;
                alert(message);
            } else {
                const response = await dispatch(studentsActions.create({data})).unwrap();
                message = `Student details has been added successfully`;
                alert(message);
                history.navigate(`/students`);
            }

        } catch (error) {
               alert(error);
        }
    }

    return (
        <React.Fragment>
            <Stack direction="column" sx={{ width: '100%', justifyContent:'center', alignItems:'center'}}>
                {/*<Box*/}
                {/*    component="form"*/}
                {/*    noValidate*/}
                {/*    autoComplete="off"*/}
                {/*>*/}
                <Stack direction="column" >
                    <FormControl>
                        <Typography component="h2" variant="h6" sx={{mb: 2}}>
                            {id ? `Student Details` : `Add New Student`}
                        </Typography>
                    </FormControl>
                </Stack>
                <Stack direction="column" sx={{width: '100%' }}>
                    {!(entity?.loading || entity?.error) &&
                    <form name="editForm" id="editForm" onSubmit={handleSubmit(onSubmit)}>
                        <Stack direction="row" sx={{display: 'flex', flexWrap: 'wrap',  justifyContent: 'center', alignItems: 'center'}}>
                            {(id) &&
                            <Stack direction="column" sx={{mt: 1, mb: 1, ml: 1, mr: 1}}>
                                <FormControl>
                                    <TextField
                                        id="id"
                                        name="id"
                                        type="text"
                                        variant='outlined'
                                        color='primary'
                                        label="Id"
                                        //placeholder={""}
                                        autoComplete={'off'}
                                        InputLabelProps={{shrink: true}}
                                        {...register('id', {
                                            required: true
                                        } )}
                                        inputProps={{
                                            readOnly: true
                                        }}
                                    />
                                </FormControl>
                            </Stack>
                            }
                            <Stack direction="column" sx={{mt:1, mb:1, ml:1, mr:1}}>
                                <FormControl>
                                    <TextField
                                        id="name"
                                        name="name"
                                        type="text"
                                        variant='outlined'
                                        color='primary'
                                        label="Name"
                                        placeholder={""}
                                        autoComplete={'off'}
                                        InputLabelProps={{ shrink: true }}
                                        {...register('name', {required: true})}
                                        error={Boolean(errors.name)}
                                        helperText={errors.name ? errors.name.message : ""}
                                    />
                                </FormControl>
                            </Stack>
                            <Stack direction="column" sx={{mt:1, mb:1, ml:1, mr:1}}>
                                <FormControl>
                                    <TextField
                                        id="address"
                                        name="address"
                                        type="text"
                                        variant='outlined'
                                        color='primary'
                                        label="Address"
                                        placeholder={""}
                                        autoComplete={'off'}
                                        InputLabelProps={{ shrink: true }}
                                        {...register('address', {required: true})}
                                        error={Boolean(errors.address)}
                                        helperText={errors.address ? errors.address.message : ""}
                                    />
                                </FormControl>
                            </Stack>
                        </Stack>
                        <Stack direction="column" sx={{mt:1, mb:1, ml:1, mr:1}}>
                            <FormControl>
                                <TextField
                                    id="phone"
                                    name="phone"
                                    type="text"
                                    variant='outlined'
                                    color='primary'
                                    label="Phone"
                                    placeholder={""}
                                    autoComplete={'off'}
                                    InputLabelProps={{ shrink: true }}
                                    {...register('phone', {required: true})}
                                    error={Boolean(errors.phone)}
                                    helperText={errors.phone ? errors.phone.message : ""}
                                />
                            </FormControl>
                        </Stack>
                        <Stack direction="column" sx={{mt:1, mb:1, ml:1, mr:1}}>
                            <FormControl>
                                <TextField
                                    id="email"
                                    name="email"
                                    type="text"
                                    variant='outlined'
                                    color='primary'
                                    label="Email"
                                    placeholder={""}
                                    autoComplete={'off'}
                                    InputLabelProps={{ shrink: true }}
                                    {...register('email', {required: true})}
                                    error={Boolean(errors.email)}
                                    helperText={errors.email ? errors.email.message : ""}
                                />
                            </FormControl>
                        </Stack>
                        <Stack direction="column" sx={{mt:1, mb:1, ml:1, mr:1}}>
                            <FormControl>
                                <InputLabel id="select-gender-label">Gender</InputLabel>
                                <Select
                                    labelId="select-gender-label"
                                    id="gender.id"
                                    name="gender.id"
                                    label="Gender"
                                    defaultValue={entity?.value?.gender?.id || 1}
                                    {...register('gender.id')}
                                >
                                    <MenuItem key={1} value={1}>Male</MenuItem>
                                    <MenuItem key={2} value={2}>Female</MenuItem>
                                </Select>
                            </FormControl>
                        </Stack>
                        <Stack direction="row" sx={{display: 'flex', flexWrap: 'wrap', mt:2, justifyContent: 'center', alignItems: 'center'}}>
                            <Stack direction="column" sx={{mt:1, mb:1, ml:1, mr:1}}>
                                <Button fullWidth variant="contained" color="primary"
                                        sx={{minWidth: '80px'}} type="submit"
                                        startIcon={<SaveOutlinedIcon/>}>Save</Button>
                            </Stack>
                            <Stack direction="column" sx={{mt:1, mb:1, ml:1, mr:1}}>
                                <Button fullWidth variant="contained" color="primary" sx={{minWidth: '30%', ml:1}} type="button" startIcon={<CancelPresentationIcon/>} onClick={(e)=> history.navigate(`/students`)}>{'Close'}</Button>
                            </Stack>
                            <Stack direction="column" sx={{mt:1, mb:1, ml:1, mr:1}}>
                                {!(entity?.loading || entity?.error) &&
                                <Button fullWidth variant="contained" color="primary" sx={{minWidth: '30%', ml: 1}}
                                        type="button" startIcon={<CancelPresentationIcon/>}
                                        onClick={(e) => deleteStudentDetails(entity?.value?.id)}>{'Delete'}</Button>
                                }
                            </Stack>
                        </Stack>
                    </form>
                    }
                </Stack>
                <Stack direction="column" sx={{mt:1, mb:1, ml:1, mr:1}}>
                    <Button variant="contained" color="primary" sx={{minWidth: '30%', ml:1}} type="button" startIcon={<PersonAddIcon/>} onClick={(e)=> history.navigate(`/students/add`)}>{'Add New Student'}</Button>
                </Stack>
            </Stack>
        </React.Fragment>
    );
}
