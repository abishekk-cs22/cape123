import React, {useState, useEffect} from 'react';
import {useDispatch, useSelector} from "react-redux";

import Grid from "@mui/material/Grid2";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import {studentsActions} from "../../../_services/essentials/store";
import {Button, Stack} from '@mui/material';
import {history} from "../../../_services/essentials/helpers";
import Link from '@mui/material/Link';
import PersonAddIcon from "@mui/icons-material/PersonAdd";

export { List };

function List() {


    const students_list = useSelector(x => x.students.list);

    const dispatch = useDispatch();

    useEffect(() => {
        //alert('Starting point');
        dispatch(studentsActions.getAll());
    }, []);

    function editDetails(id){
        //history.navigate('/students/'+id);
        history.navigate(`/students/${id}`);
    }

  return (
      <Stack direction="column" sx={{ justifyContent: 'space-between' }}>
        <Stack
            direction="column"
            sx={{ justifyContent: 'space-between', mb: 2 }}
        >
          <Stack direction="column" sx={{ justifyContent: 'space-between', alignItems: 'center',  mb: 2 }}>
            <Typography component="h2" variant="h6" sx={{fontWeight: 'bold'}}>All Students</Typography>
          </Stack>
        </Stack>
        <Stack direction="column" sx={{display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
          <Grid container sx={{width: '100%',display: 'flex', justifyContent: 'center', alignItems: 'center'}}>
            {!(students_list?.loading || students_list?.error) ? (
                (students_list && students_list?.value.length>0) ? (
                    students_list?.value?.map((student, index) => (
                        <Grid key={index} sx={{wdth: '800px', border:1 , mt:0.5, mb:0.5, ml:0.5, mr:0.5, }}>
                          <Card variant="outlined" sx={{ flexGrow: 1,
                            border: '1px solid #3381f4',
                            borderRadius: '4px'
                          }}>
                            <CardContent>
                              <Stack direction="column" sx={{wdth: '800px', justifyContent: 'space-between', flexGrow: '1', gap: 1 }}>
                                <Stack
                                    direction="column"
                                    sx={{ justifyContent: 'space-between', flexGrow: '1', gap: 1 }}
                                >
                                    <Stack sx={{ justifyContent: 'space-between' }}>
                                        <Typography sx={{ fontSize: '24px', color: 'green' }}>
                                            Id: {student.id}
                                        </Typography>
                                    </Stack>
                                    <Stack sx={{ justifyContent: 'space-between' }}>
                                        <Typography sx={{ fontSize: '24px', color: 'green' }}>
                                          Name:  <Link href={`/students/edit/${student.id}`}>{student.name}</Link>
                                        </Typography>
                                    </Stack>
                                    <Stack sx={{ justifyContent: 'space-between' }}>
                                        <Typography sx={{ fontSize: '24px', color: 'green' }}>
                                            Address: {student.address}
                                        </Typography>
                                    </Stack>
                                    <Stack sx={{ justifyContent: 'space-between' }}>
                                        <Typography sx={{ fontSize: '24px', color: 'green' }}>
                                            Phone: {student.phone}
                                        </Typography>
                                    </Stack>
                                    <Stack sx={{ justifyContent: 'space-between' }}>
                                        <Typography sx={{ fontSize: '24px', color: 'green' }}>
                                            Email: {student.email}
                                        </Typography>
                                    </Stack>
                                    <Stack sx={{ justifyContent: 'space-between' }}>
                                        <Typography sx={{ fontSize: '24px', color: 'green' }}>
                                            Gender: {student.gender.name}
                                        </Typography>
                                    </Stack>
                                </Stack>
                              </Stack>
                            </CardContent>
                          </Card>
                        </Grid>
                    ))) : (
                    <Typography component="h2" variant="subtitle2">
                      No records found.
                    </Typography>
                )
            )  : (
                <Typography component="h2" variant="subtitle2">
                  Please wait...
                </Typography>
            )
            }
          </Grid>
        </Stack>
      <Stack direction="column" sx={{ width: '200px', mt:10, mb:1, ml:1, mr:1}}>
          <Button fullWidth variant="contained" color="primary" sx={{minWidth: '30%', ml:1}} type="button" startIcon={<PersonAddIcon/>} onClick={(e)=> history.navigate(`/students/add`)}>{'Add New Student'}</Button>
      </Stack>
      </Stack>
  )
}