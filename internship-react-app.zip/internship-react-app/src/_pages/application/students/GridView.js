import React, {useState, useEffect} from 'react';
import {useDispatch, useSelector} from "react-redux";

import Grid from "@mui/material/Grid2";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import {studentsActions} from "../../../_services/essentials/store";
import {Button, Stack} from '@mui/material';
import {history} from "../../../_services/essentials/helpers";
import Link from '@mui/material/Link';
import PersonAddIcon from "@mui/icons-material/PersonAdd";
import { DataGrid } from '@mui/x-data-grid';

export { GridView };

function GridView() {


    const students_list = useSelector(x => x.students.list);

    const dispatch = useDispatch();

    useEffect(() => {
        //alert('Starting point');
        dispatch(studentsActions.getAll());
    }, []);

    function editDetails(id){
        //history.navigate('/students/'+id);
        history.navigate(`/students/${id}`);
    }

    const columns = [
        { field: 'id', headerName: 'ID', width: 90 },
        {
            field: 'name',
            headerName: 'Name',
            width: 150,
            editable: true,
        },
        {
            field: 'address',
            headerName: 'Address',
            width: 150,
            editable: true,
        },
        {
            field: 'phone',
            headerName: 'Phone',
            width: 110,
            editable: true,
        },
        {
            field: 'email',
            headerName: 'email',
            width: 220,
            editable: true,
        },
        {
            field: 'gender',
            headerName: 'gender',
            width: 160,
            renderCell: (params) =>
                <Typography sx={{fontSize: '14px', mt: 2}}>{params.value.name}</Typography>
        },
    ];


  return (
      <Stack direction="column" sx={{ justifyContent: 'space-between' }}>
        <Stack
            direction="column"
            sx={{ justifyContent: 'space-between', mb: 2 }}
        >
          <Stack direction="column" sx={{ justifyContent: 'space-between', alignItems: 'center',  mb: 2 }}>
            <Typography component="h2" variant="h6" sx={{fontWeight: 'bold'}}>All Students</Typography>
          </Stack>
        </Stack>
        <Stack direction="column" sx={{display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
          <Grid container sx={{width: '100%',display: 'flex', justifyContent: 'center', alignItems: 'center'}}>
            {!(students_list?.loading || students_list?.error) &&
                <DataGrid
                    rows={students_list?.value}
                    columns={columns}
                    initialState={{
                        pagination: {
                            paginationModel: {
                                pageSize: 5,
                            },
                        },
                    }}
                    pageSizeOptions={[5]}
                    checkboxSelection
                    disableRowSelectionOnClick
                />
            }
          </Grid>
        </Stack>
      <Stack direction="column" sx={{ width: '200px', mt:10, mb:1, ml:1, mr:1}}>
          <Button fullWidth variant="contained" color="primary" sx={{minWidth: '30%', ml:1}} type="button" startIcon={<PersonAddIcon/>} onClick={(e)=> history.navigate(`/students/add`)}>{'Add New Student'}</Button>
      </Stack>
      </Stack>
  )
}