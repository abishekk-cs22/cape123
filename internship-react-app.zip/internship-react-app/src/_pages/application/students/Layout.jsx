import React from 'react';
import { Routes, Route } from 'react-router-dom';

import { List, AddEdit, GridView } from './';

export { Layout };

function Layout() {
    return (
        <div className="p-4">
            <div className="container">
                <Routes>
                    <Route index element={<List />} />
                    <Route path="grid"  element={<GridView />} />
                    <Route path="add" element={<AddEdit />} />
                    <Route path="edit/:id" element={<AddEdit />} />
                </Routes>
            </div>
        </div>
    );
}
