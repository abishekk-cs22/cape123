import React, { useState } from "react";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import { useParams } from 'react-router-dom';
import Button from "@mui/material/Button";
import {Details } from './Details'
import {history} from "../../_services/essentials/helpers";

export { Bio };



function Bio() {

    const name = "John";
    const age = 10;

    const [count,  setCount ] =  useState(0);

    function increase(){
        setCount(count+1);
    }

    function decrease() {
        setCount(count-1);
    }

    function openEvansPage(){
        history.navigate('/evans', {state: {name: name, age: age, count: count }});
    }



    return (
        <Box sx={{ }} >
            <Typography variant="h6" component="h6">
                Name: {name}
            </Typography>
            <Typography variant="h6" component="h6">
                Age: {age}
            </Typography>
            <Details name={name} age={age} />
            <Typography variant="h2" component="h2">
                Count: {count}
            </Typography>

            <Button variant="contained" onClick={() => increase() } sx={{ml: 2}}>Increase</Button>
            <Button variant="contained" onClick={() => decrease() } sx={{ml: 2}}>Decrease</Button>
            <Button variant="contained" onClick={() => openEvansPage() } sx={{ml: 2}}>Evans page</Button>
            { (count>0 && count<10) &&
                <Typography variant="h2" component="h2">
                Count is less than 10
                </Typography>
            }
            { (count>=10 && count<20) &&
            <Typography variant="h2" component="h2">
                Count is between 10 and 20
            </Typography>
            }

        </Box>

    );
}