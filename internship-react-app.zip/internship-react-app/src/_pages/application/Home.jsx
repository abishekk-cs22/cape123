import React, { useState } from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import {history} from "../../_services/essentials/helpers";

export { Home };


function Home() {

    return (
        <Box sx={{ }} >
            <Button variant="contained" onClick={() => history.navigate('/bio') } sx={{ml: 2}}>Bio page</Button>
            <Button variant="contained" onClick={() => history.navigate('/students') } sx={{ml: 2}}>Students Managment</Button>
        </Box>

    );
}