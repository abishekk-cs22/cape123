import React from "react";
import Stack from '@mui/material/Stack';
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import {history} from "../../_services/essentials/helpers";

export { Evans };

function Evans(props) {

    const inoutData = history.location?.state;
    //alert('inoutData: '+JSON.stringify(inoutData));

    const {name, age, count} = inoutData;

    return (
        <Stack>
            <div>Happy Coding</div>
            <Typography variant="h1" component="h2">
                Hi {name}. Your age is: {age}
            </Typography>
            <Typography variant="h1" component="h2">
                Lastest Count: {count}
            </Typography>
            <Button variant="contained" onClick={() => history.navigate('/') }>Baxk to home page</Button>
        </Stack>
    );
}